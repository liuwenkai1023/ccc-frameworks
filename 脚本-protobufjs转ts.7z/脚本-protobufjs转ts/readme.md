## 操作步骤
1. 安装 Node.**js**

2. 安装 protobufjs@6.8.8
    1. 打开终端执行: npm install protobufjs@6.8.8 -g

3. 运行 protobufjs2ts.bat，把生成的_output文件夹复制到你的assets中

4. 为了使工程更纯粹可以进行以下操作（**可选操作**）

   1. 生成的*.d.ts中 
       ```
       把     import * as $protobuf from "protobufjs";
       替换为 import * as $protobuf from protobuf;
       ```

   2. 生成的*.js中 
   
        ```
       把     var $protobuf = require("protobufjs/minimal");
       替换为 var $protobuf = protobuf;
       ```

ps： 不进行4操作也可以正常使用
