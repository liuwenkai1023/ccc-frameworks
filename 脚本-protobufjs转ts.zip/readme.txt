1、需要安装 Node.js

2、需要安装 protobufjs
打开终端执行: npm install protobufjs

3、完成以上两步就可以使用这个脚本一键导出了